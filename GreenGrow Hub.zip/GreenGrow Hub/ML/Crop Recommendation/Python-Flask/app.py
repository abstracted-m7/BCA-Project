
#Manish Giri BCA
#ngrok_auth : ngrok config add-authtoken 2u2XKXdmrDuIWzZwi1PzJsQUX9d_P1bsw3A9QGvnBCc658VE

# from flask import Flask, request, jsonify, render_template
# import numpy as np
# import pickle
# from flask_ngrok import run_with_ngrok

# # Load the model and scalers
# model = pickle.load(open('model.pkl', 'rb'))
# sc = pickle.load(open('standscaler.pkl', 'rb'))
# mx = pickle.load(open('minmaxscaler.pkl', 'rb'))

# # Initialize Flask app
# app = Flask(__name__)

# @app.route('/')
# def index():
#     return render_template("index.html")  # Render the HTML form for input

# @app.route("/predict", methods=['POST'])
# def predict():
#     # Get data from the form
#     N = float(request.form['Nitrogen'])
#     P = float(request.form['Phosporus'])
#     K = float(request.form['Potassium'])
#     temp = float(request.form['Temperature'])
#     humidity = float(request.form['Humidity'])
#     ph = float(request.form['pH'])
#     rainfall = float(request.form['Rainfall'])

#     feature_list = [N, P, K, temp, humidity, ph, rainfall]
#     single_pred = np.array(feature_list).reshape(1, -1)

#     mx_features = mx.transform(single_pred)
#     sc_mx_features = sc.transform(mx_features)
#     prediction = model.predict(sc_mx_features)

#     # Mapping prediction result to crop
#     crop_dict = {1: "Rice", 2: "Maize", 3: "Jute", 4: "Cotton", 5: "Coconut", 6: "Papaya", 7: "Orange",
#                  8: "Apple", 9: "Muskmelon", 10: "Watermelon", 11: "Grapes", 12: "Mango", 13: "Banana",
#                  14: "Pomegranate", 15: "Lentil", 16: "Blackgram", 17: "Mungbean", 18: "Mothbeans",
#                  19: "Pigeonpeas", 20: "Kidneybeans", 21: "Chickpea", 22: "Coffee"}

#     result = crop_dict.get(prediction[0], "Unknown Crop")

#     return render_template("index.html", result=result)  # Show the prediction on the HTML page

# if __name__ == "__main__":
#     run_with_ngrok(app)  # Enable ngrok for public URL
#     app.config['DEBUG'] = True  # Enable debug mode separately
#     app.run()  # Run the app without the debug parameter


# Manish Giri BCA
# ngrok_auth : ngrok config add-authtoken 2u2XKXdmrDuIWzZwi1PzJsQUX9d_P1bsw3A9QGvnBCc658VE

from flask import Flask, request, jsonify, render_template
import numpy as np
import pickle
from flask_ngrok import run_with_ngrok

# Load the model and scalers
model = pickle.load(open('model.pkl', 'rb'))
sc = pickle.load(open('standscaler.pkl', 'rb'))
mx = pickle.load(open('minmaxscaler.pkl', 'rb'))

# Initialize Flask app
app = Flask(__name__)
run_with_ngrok(app)  # Enable ngrok for public URL

@app.route('/')
def index():
    return render_template("index.html")  # HTML form for user input

@app.route("/predict", methods=['POST'])
def predict():
    try:
        # Get input values from HTML form
        N = float(request.form['Nitrogen'])
        P = float(request.form['Phosphorus'])  # Correct spelling
        K = float(request.form['Potassium'])
        temp = float(request.form['Temperature'])
        humidity = float(request.form['Humidity'])
        ph = float(request.form['pH'])
        rainfall = float(request.form['Rainfall'])

        # Prepare feature array
        features = np.array([[N, P, K, temp, humidity, ph, rainfall]])
        normalized = mx.transform(features)
        scaled = sc.transform(normalized)

        prediction = model.predict(scaled)

        crop_dict = {
            1: "Rice", 2: "Maize", 3: "Jute", 4: "Cotton", 5: "Coconut",
            6: "Papaya", 7: "Orange", 8: "Apple", 9: "Muskmelon", 10: "Watermelon",
            11: "Grapes", 12: "Mango", 13: "Banana", 14: "Pomegranate",
            15: "Lentil", 16: "Blackgram", 17: "Mungbean", 18: "Mothbeans",
            19: "Pigeonpeas", 20: "Kidneybeans", 21: "Chickpea", 22: "Coffee"
        }

        predicted_crop = crop_dict.get(int(prediction[0]), "Unknown Crop")
        return render_template("index.html", result=predicted_crop)

    except Exception as e:
        return render_template("index.html", result=f"Error: {str(e)}")

if __name__ == "__main__":
    app.config['DEBUG'] = True
    app.run()
