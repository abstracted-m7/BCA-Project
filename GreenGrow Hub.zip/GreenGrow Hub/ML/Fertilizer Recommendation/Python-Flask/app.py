

#account form Manish Giri BWU
#ngrok_Auth: ngrok config add-authtoken 2u2XKXdmrDuIWzZwi1PzJsQUX9d_P1bsw3A9QGvnBCc658VE


from flask import Flask, render_template, request
import pickle
import numpy as np
from flask_ngrok import run_with_ngrok  # Import flask_ngrok

# Load the trained model
model = pickle.load(open('classifier1.pkl', 'rb'))

# Initialize Flask app
app = Flask(__name__)
run_with_ngrok(app)  # Enable ngrok when running the app

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get input values from form
        Nitrogen = float(request.form.get('Nitrogen'))
        Potassium = float(request.form.get('Potassium'))
        Phosphorous = float(request.form.get('Phosphorous'))

        # Make prediction
        result = model.predict(np.array([[Nitrogen, Potassium, Phosphorous]]))

        # Define fertilizer types
        fertilizer_types = {
            0: 'TEN-TWENTY SIX-TWENTY SIX',
            1: 'Fourteen-Thirty Five-Fourteen',
            2: 'Seventeen-Seventeen-Seventeen',
            3: 'TWENTY-TWENTY',
            4: 'TWENTY EIGHT-TWENTY EIGHT',
            5: 'DAP',
            6: 'UREA'
        }

        return render_template('index.html', result=fertilizer_types.get(result[0], "Unknown"))

    except Exception as e:
        return render_template('index.html', result=f"Error: {str(e)}")

if __name__ == '__main__':
    app.run()  # No need to specify debug=True; flask_ngrok handles it
