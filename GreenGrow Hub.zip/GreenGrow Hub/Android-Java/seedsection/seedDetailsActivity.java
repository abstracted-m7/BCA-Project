public class seedDetailsActivity extends AppCompatActivity {
    // Seed data
    String[] seedNames = {
          //Enter seed name
    };

    String[] seedPrices = {
           //enter seed price
    };


    int[] seedImages = {
           //enter seeds image name
    };

    // Add these arrays for seed details
    private String[] seedDescriptions = {
        //Enter seed description
            "Aus Paddy: Early maturing variety, drought tolerant, suitable for direct seeding.",
            "Boro Paddy: Winter season rice, high yielding, requires irrigation.",
               };

   

    // Add these at class level
    private static ArrayList<CartItem> cartItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seed_details);
        EdgeToEdge.enable(this);

        GridView seedGridView = findViewById(R.id.seedGridView);
        
        // Enable hardware acceleration for better scrolling
        seedGridView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        
        seedGridAdapter adapter = new seedGridAdapter(this, seedNames, seedPrices, seedImages);
        seedGridView.setAdapter(adapter);

        seedGridView.setOnItemClickListener((adapterView, view, position, l) -> {
            showSeedDetailsDialog(position);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.seed), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView cartIcon = findViewById(R.id.seed_cart_icon);
        cartIcon.setOnClickListener(v -> {
            Intent intent = new Intent(seedDetailsActivity.this, SeedCartActivity.class);
            startActivity(intent);
        });
    }

    private void showSeedDetailsDialog(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.seed_details_dialog, null);

        ImageView seedImage = dialogView.findViewById(R.id.dialog_seed_image);
        TextView seedName = dialogView.findViewById(R.id.dialog_seed_name);
        TextView seedPrice = dialogView.findViewById(R.id.dialog_seed_price);
        TextView seedDescription = dialogView.findViewById(R.id.dialog_seed_description);
        TextView seedDescriptionBengali = dialogView.findViewById(R.id.dialog_seed_description_bengali);
        EditText quantityInput = dialogView.findViewById(R.id.quantity_input);
        Button addToCartButton = dialogView.findViewById(R.id.add_to_cart_button);

        seedImage.setImageResource(seedImages[position]);
        seedName.setText(seedNames[position]);
        seedPrice.setText(seedPrices[position]);
        seedDescription.setText(seedDescriptions[position]);
        seedDescriptionBengali.setText(seedDescriptionsBengali[position]);

        AlertDialog dialog = builder.setView(dialogView).create();

        addToCartButton.setOnClickListener(v -> {
            String quantityStr = quantityInput.getText().toString();
            if (!quantityStr.isEmpty()) {
                int quantity = Integer.parseInt(quantityStr);
                if (quantity > 0) {
                    CartItem newItem = new CartItem(
                        seedNames[position],
                        seedImages[position],
                        getPriceValue(seedPrices[position]),
                        quantity
                    );
                    addToCart(newItem);
                    Toast.makeText(this, "Added to cart!", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                } else {
                    Toast.makeText(this, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter quantity", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void addToCart(CartItem newItem) {
        boolean itemExists = false;
        for (CartItem item : cartItems) {
            if (item.getName().equals(newItem.getName())) {
                item.setQuantity(item.getQuantity() + newItem.getQuantity());
                itemExists = true;
                break;
            }
        }
        if (!itemExists) {
            cartItems.add(newItem);
        }
    }

    private double getPriceValue(String priceStr) {
        // Extract numeric value from price string (e.g., "Price: 200/kg" -> 200.0)
        return Double.parseDouble(priceStr.replaceAll("[^0-9]", ""));
    }

    ImageView imageView;
    public void backFrmSeedsCart ( View view){
        imageView = findViewById(R.id.backFrmSeedsCart);
        startActivity(new Intent(seedDetailsActivity.this, MainActivity.class));
        Toast.makeText(this, "Back to main Page...!!", Toast.LENGTH_SHORT).show();
        finish();
    }

    // Add this method to access cart items from other activities
    public static ArrayList<CartItem> getCartItems() {
        return cartItems;
    }

    // Add this method to clear the cart
    public static void clearCart() {
        cartItems.clear();
    }
}