public class CartListActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_list);

        sharedPreferences = getSharedPreferences("DeliveryAddresses", MODE_PRIVATE);   
        // Update checkout button text
        checkoutButton.setText("Buy Now");

        adapter = new CartListAdapter(this, fartilizerDetailsActivity.cartItems);
        cartListView.setAdapter(adapter);

        updateTotalPrice();

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        
        if (currentUser == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            // Fix the class reference to loginActivity
            startActivity(new Intent(this, loginActivity.class));
            finish();
            return;
        }
        
        userId = currentUser.getUid();
        
        // Initialize database reference
        ordersRef = FirebaseDatabase.getInstance().getReference()
            .child("users")
            .child(userId)
            .child("orders");

        checkoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fartilizerDetailsActivity.cartItems.isEmpty()) {
                    Toast.makeText(CartListActivity.this, 
                        "Cart is empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                showDeliveryAddressDialog();
            }
        });

        //for view previous order
        TextView viewOrdersButton = findViewById(R.id.view_orders_button);
        viewOrdersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if user is logged in
                if (mAuth.getCurrentUser() != null) {
                    startActivity(new Intent(CartListActivity.this, MyOrdersActivity.class));
                } else {
                    Toast.makeText(CartListActivity.this, 
                        "Please login to view orders", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(CartListActivity.this, loginActivity.class));
                }
            }
        });
    }

    private void showDeliveryAddressDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_delivery_address);

        EditText addressInput = dialog.findViewById(R.id.address_input);
        EditText pincodeInput = dialog.findViewById(R.id.pincode_input);
        EditText phoneInput = dialog.findViewById(R.id.phone_input);
        Button confirmButton = dialog.findViewById(R.id.confirm_order_btn);

        // Load saved address if exists
        addressInput.setText(sharedPreferences.getString("lastAddress", ""));
        pincodeInput.setText(sharedPreferences.getString("lastPincode", ""));
        phoneInput.setText(sharedPreferences.getString("lastPhone", ""));

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String address = addressInput.getText().toString().trim();
                String pincode = pincodeInput.getText().toString().trim();
                String phone = phoneInput.getText().toString().trim();

                if (address.isEmpty() || pincode.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(CartListActivity.this, 
                        "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (pincode.length() != 6) {
                    Toast.makeText(CartListActivity.this, 
                        "Please enter valid PIN code", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (phone.length() != 10) {
                    Toast.makeText(CartListActivity.this, 
                        "Please enter valid phone number", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Save address to SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("lastAddress", address);
                editor.putString("lastPincode", pincode);
                editor.putString("lastPhone", phone);
                editor.apply();

                // Create delivery address object
                DeliveryAddress deliveryAddress = new DeliveryAddress(address, pincode, phone);

                // Process order
                processOrder(deliveryAddress);
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void processOrder(DeliveryAddress deliveryAddress) {
        try {
            showLoadingDialog();
            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser == null) {
                hideLoadingDialog();
                Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, loginActivity.class));
                finish();
                return;
            }
            String orderId = UUID.randomUUID().toString();
            final double totalAmount = calculateTotalAmount();

            Order order = new Order(
                orderId,
                currentUser.getUid(),
                currentUser.getEmail(),
                deliveryAddress.getFullAddress(),
                deliveryAddress.getPinCode(),
                deliveryAddress.getPhoneNumber(),
                new ArrayList<>(fartilizerDetailsActivity.cartItems),
                totalAmount,
                deliveryAddress.getFullAddress()
            );

            DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
            DatabaseReference userOrderRef = rootRef.child("users")
                .child(currentUser.getUid())
                .child("orders")
                .child(orderId);
            DatabaseReference allOrdersRef = rootRef.child("all_orders").child(orderId);

            // First save to user orders
            userOrderRef.setValue(order)
                .addOnSuccessListener(aVoid -> {
                    // Then save to all orders
                    allOrdersRef.setValue(order)
                        .addOnSuccessListener(aVoid2 -> {
                            hideLoadingDialog();
                            // Clear cart in background
                            new Thread(() -> {
                                fartilizerDetailsActivity.cartItems.clear();
                                runOnUiThread(() -> {
                                    updateTotalPrice();
                                    adapter.notifyDataSetChanged();
                                    Toast.makeText(CartListActivity.this, 
                                        "Order placed successfully!", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(CartListActivity.this, OrderDetailsActivity.class);
                                    intent.putExtra("order_id", orderId);
                                    startActivity(intent);
                                    finish();
                                });
                            }).start();
                        })
                        .addOnFailureListener(e -> {
                            hideLoadingDialog();
                            Toast.makeText(CartListActivity.this, 
                                "Failed to place order: " + e.getMessage(), 
                                Toast.LENGTH_SHORT).show();
                        });
                })
                .addOnFailureListener(e -> {
                    hideLoadingDialog();
                    Toast.makeText(CartListActivity.this, 
                        "Failed to place order: " + e.getMessage(), 
                        Toast.LENGTH_SHORT).show();
                });

        } catch (Exception e) {
            hideLoadingDialog();
            Toast.makeText(this, "Error processing order: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
            Log.e("CartListActivity", "Order processing error", e);
        }
    }

    private double calculateTotalAmount() {
        double total = 0;
        for (CartItem item : fartilizerDetailsActivity.cartItems) {
            total += item.getTotalPrice();
        }
        return total;
    }

    public void updateTotalPrice() {
        double total = 0;
        for (CartItem item : fartilizerDetailsActivity.cartItems) {
            total += item.getTotalPrice();
        }
        totalPriceText.setText("Total: ₹" + String.format("%.2f", total));
    }

    private void showLoadingDialog() {
        if (loadingDialog == null) {
            loadingDialog = new Dialog(this);
            loadingDialog.setContentView(R.layout.dialog_loading);
            loadingDialog.setCancelable(false);
        }
        loadingDialog.show();
    }

    private void hideLoadingDialog() {
        if (loadingDialog != null && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }
    }
} 