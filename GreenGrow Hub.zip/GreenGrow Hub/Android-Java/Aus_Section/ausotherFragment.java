public class ausotherFragment extends Fragment {
    FragmentAusotherBinding binding;



    public ausotherFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAusotherBinding.inflate(inflater, container, false);

        //for video
        WebView webview=binding.ausothervideo;
        String video="<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/JCDf7xXMhRw?si=9DCObjet6hrOBZOm\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>";
        webview.loadData(video,"text/html","utf-8");
        webview.getSettings().setJavaScriptEnabled(true);
        webview.setWebChromeClient(new WebChromeClient());


        // Get the string from resources
        String rawText = getString(R.string.ausOthers);

       
        binding.ausotherdetail.setText(rawText);

        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}