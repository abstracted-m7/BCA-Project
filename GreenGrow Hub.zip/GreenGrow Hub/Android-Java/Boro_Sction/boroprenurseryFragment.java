

public class boroprenurseryFragment extends Fragment {
    FragmentBoroprenurseryBinding binding;



    public boroprenurseryFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentBoroprenurseryBinding.inflate(inflater, container, false);

        //for video1
        WebView webview=binding.boroprenurseryvideo;
        String video="<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/TSPmBfnzhZk?si=nbOo1o3yeH6vglht\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>";
        webview.loadData(video,"text/html","utf-8");
        webview.getSettings().setJavaScriptEnabled(true);
        webview.setWebChromeClient(new WebChromeClient());
        //for video2
        WebView webview2=binding.boroprenurseryvideo2;
        String video2="<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/u84pjaqCvVY?si=x-Vegs072rHLE7wy\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>";
        webview2.loadData(video2,"text/html","utf-8");
        webview2.getSettings().setJavaScriptEnabled(true);
        webview2.setWebChromeClient(new WebChromeClient());


        // Get the string from resources
        String rawText = getString(R.string.boroPrenursery);

        binding.boroprenurserydetail.setText(rawText);

        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}