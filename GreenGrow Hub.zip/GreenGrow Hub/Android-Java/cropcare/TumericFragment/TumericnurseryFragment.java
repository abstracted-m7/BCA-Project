public class TumericnurseryFragment extends Fragment {
    FragmentTumericnurseryBinding binding;


    public TumericnurseryFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentTumericnurseryBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Turmeric_Nursery);
        // Set the formatted text to the TextView
        binding.Tumericnurserydetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}