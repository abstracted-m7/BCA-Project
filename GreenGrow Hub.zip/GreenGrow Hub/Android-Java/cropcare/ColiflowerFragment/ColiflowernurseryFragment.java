public class ColiflowernurseryFragment extends Fragment {
    FragmentColiflowernurseryBinding binding;

    public ColiflowernurseryFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentColiflowernurseryBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Cauliflower_Nursery);
        // Set the formatted text to the TextView
        binding.Coliflowernurserydetail.setText(rawText);




        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}