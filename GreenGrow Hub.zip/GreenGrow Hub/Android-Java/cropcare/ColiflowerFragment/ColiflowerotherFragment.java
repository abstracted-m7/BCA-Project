public class ColiflowerotherFragment extends Fragment {
    FragmentColiflowerotherBinding binding;


    public ColiflowerotherFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentColiflowerotherBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Cauliflower_others);
        // Set the formatted text to the TextView
        binding.Coliflowerotherdetail.setText(rawText);




        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}