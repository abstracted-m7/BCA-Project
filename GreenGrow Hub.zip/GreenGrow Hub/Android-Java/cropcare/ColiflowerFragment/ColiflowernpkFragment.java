public class ColiflowernpkFragment extends Fragment {
    FragmentColiflowernpkBinding binding;

    public ColiflowernpkFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentColiflowernpkBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Cauliflower_NPK_Fertilizer_and_Soil_Management);
        // Set the formatted text to the TextView
        binding.Coliflowernpkdetail.setText(rawText);



        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}