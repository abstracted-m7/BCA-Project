public class CabbagenpkFragment extends Fragment {
    FragmentCabbagenpkBinding binding;



    public CabbagenpkFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCabbagenpkBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Cabbage_NPK_Fertilizer_and_Soil_Management);
        // Set the formatted text to the TextView
        binding.Cabbagenpkdetail.setText(rawText);



        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}