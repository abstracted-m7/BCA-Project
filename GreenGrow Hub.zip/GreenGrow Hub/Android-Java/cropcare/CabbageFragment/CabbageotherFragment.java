public class CabbageotherFragment extends Fragment {
    FragmentCabbageotherBinding binding;

    public CabbageotherFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCabbageotherBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Cabbage_Others);
        // Set the formatted text to the TextView
        binding.Cabbageotherdetail.setText(rawText);



        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}