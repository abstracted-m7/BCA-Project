public class LemonotherFragment extends Fragment {
    FragmentLemonotherBinding binding;


    public LemonotherFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentLemonotherBinding.inflate(inflater, container, false);
        String rawText = getString(R.string.Lemon_Others);
        // Set the formatted text to the TextView
        binding.Lemonotherdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}