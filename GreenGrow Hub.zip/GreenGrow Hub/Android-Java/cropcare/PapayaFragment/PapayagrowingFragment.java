public class PapayagrowingFragment extends Fragment {
    FragmentPapayagrowingBinding binding;

    public PapayagrowingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentPapayagrowingBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Papaya_Growing_Process);
        // Set the formatted text to the TextView
        binding.Papayagrowingdetail.setText(rawText);


        return binding.getRoot();
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}