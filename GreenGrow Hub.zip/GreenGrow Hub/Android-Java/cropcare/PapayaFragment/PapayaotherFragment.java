public class PapayaotherFragment extends Fragment {
    FragmentPapayaotherBinding binding;


    public PapayaotherFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentPapayaotherBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Papaya_Others);
        // Set the formatted text to the TextView
        binding.Papayaotherdetail.setText(rawText);


        return binding.getRoot();
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}