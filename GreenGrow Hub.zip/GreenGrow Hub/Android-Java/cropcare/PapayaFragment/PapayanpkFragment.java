public class PapayanpkFragment extends Fragment {
    FragmentPapayanpkBinding binding;

    public PapayanpkFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentPapayanpkBinding.inflate(inflater, container, false);
        String rawText = getString(R.string.Papaya_NPK_Fertilizer_and_Soil_Management);
        // Set the formatted text to the TextView
        binding.Papayanpkdetail.setText(rawText);


        return binding.getRoot();
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}