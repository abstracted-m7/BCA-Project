public class BeetgrowingFragment extends Fragment {
    FragmentBeetgrowingBinding binding;


    public BeetgrowingFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentBeetgrowingBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Beet_Growing_Process);
        // Set the formatted text to the TextView
        binding.Beetgrowingdetail.setText(rawText);




        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}