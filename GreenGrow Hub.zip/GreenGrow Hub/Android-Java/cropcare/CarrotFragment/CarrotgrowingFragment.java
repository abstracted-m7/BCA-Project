public class CarrotgrowingFragment extends Fragment {
    FragmentCarrotgrowingBinding binding;


    public CarrotgrowingFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCarrotgrowingBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Carrot_Growing_Process);
        // Set the formatted text to the TextView
        binding.Carrotgrowingdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}