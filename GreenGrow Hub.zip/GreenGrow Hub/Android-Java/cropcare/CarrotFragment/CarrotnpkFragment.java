public class CarrotnpkFragment extends Fragment {
    FragmentCarrotnpkBinding binding;


    public CarrotnpkFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCarrotnpkBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Carrot_NPK_Fertilizer_and_Soil_Management);
        // Set the formatted text to the TextView
        binding.Carrotnpkdetail.setText(rawText);



        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}