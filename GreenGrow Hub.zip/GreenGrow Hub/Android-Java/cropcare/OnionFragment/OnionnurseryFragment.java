public class OnionnurseryFragment extends Fragment {
    FragmentOnionnurseryBinding binding;

    public OnionnurseryFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentOnionnurseryBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Onion_Nursery);
        // Set the formatted text to the TextView
        binding.Onionnurserydetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}