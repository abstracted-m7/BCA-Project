public class OniongrowingFragment extends Fragment {
    FragmentOniongrowingBinding binding;


    public OniongrowingFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentOniongrowingBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Onion_Growing_Process);
        // Set the formatted text to the TextView
        binding.Oniongrowingdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}