public class viewPagerOnionAdapter extends FragmentPagerAdapter {
    public viewPagerOnionAdapter(@NonNull FragmentManager fm){
        super(fm);
    }
    public Fragment getItem(int position) {
        if(position==0){
            return new OnionnurseryFragment();
        }else if(position==1){
            return new OnionnpkFragment();
        }else if(position==2){
            return new OnionnurseryFragment();
        }else{
            return new OnionotherFragment();
        }
    }

    @Override
    public int getCount() {
        return 4;//how meny fregment or tab is used.
    }

    @Override
    public CharSequence getPageTitle(int position) {
        if(position==0){
            return "Nursery";
        }else if(position==1){
            return "NPK Fertilizer";
        }else if(position==2){
            return "Growing Process";
        }else{
            return "Other";
        }
    }
}
