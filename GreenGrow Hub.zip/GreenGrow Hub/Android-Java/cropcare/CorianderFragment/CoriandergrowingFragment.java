public class CoriandergrowingFragment extends Fragment {
    FragmentCoriandergrowingBinding binding;

    public CoriandergrowingFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCoriandergrowingBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Coriander_Growing_Process);
        // Set the formatted text to the TextView
        binding.Coriandergrowingdetail.setText(rawText);




        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}