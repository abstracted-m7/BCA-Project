public class LadisfingerotherFragment extends Fragment {
    FragmentLadisfingerotherBinding binding;



    public LadisfingerotherFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentLadisfingerotherBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Ladyfinger_Others);
        // Set the formatted text to the TextView
        binding.Ladyfingerotherdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}