public class LadisfingernurseryFragment extends Fragment {
    FragmentLadisfingernurseryBinding binding;


    public LadisfingernurseryFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentLadisfingernurseryBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Ladyfinger_Nursery_Details);
        // Set the formatted text to the TextView
        binding.Ladyfingernurserydetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}