public class BeannurseryFragment extends Fragment {
    FragmentBeannurseryBinding binding;


    public BeannurseryFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentBeannurseryBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Beans_Nursery);
        // Set the formatted text to the TextView
        binding.Beannurserydetail.setText(rawText);



        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}