public class BeannpkFragment extends Fragment {
    FragmentBeannpkBinding binding;



    public BeannpkFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentBeannpkBinding.inflate(inflater, container, false);
        String rawText = getString(R.string.Beans_NPK_Fertilizer_and_Soil_Management);
        // Set the formatted text to the TextView
        binding.beannpkdetail.setText(rawText);




        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}