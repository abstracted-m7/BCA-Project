public class GingergrowingFragment extends Fragment {
    FragmentGingergrowingBinding binding;


    public GingergrowingFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentGingergrowingBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Ginger_Growing_Process);
        // Set the formatted text to the TextView
        binding.Gingergrowingdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}