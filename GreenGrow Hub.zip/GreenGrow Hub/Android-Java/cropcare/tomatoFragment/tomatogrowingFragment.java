public class tomatogrowingFragment extends Fragment {
    FragmentTomatogrowingBinding binding;



    public tomatogrowingFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentTomatogrowingBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Tomato_Growing_Process_details);
        // Set the formatted text to the TextView
        binding.tomatogrowingdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}