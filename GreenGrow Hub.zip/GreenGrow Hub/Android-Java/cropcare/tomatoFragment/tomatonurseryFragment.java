public class tomatonurseryFragment extends Fragment {
    FragmentTomatonurseryBinding binding;
    public tomatonurseryFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentTomatonurseryBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Tomato_Nursery);
        // Set the formatted text to the TextView
        binding.tomatonurserydetail.setText(rawText);
        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}