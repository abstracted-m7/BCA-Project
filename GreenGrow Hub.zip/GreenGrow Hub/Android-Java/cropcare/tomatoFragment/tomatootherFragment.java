public class tomatootherFragment extends Fragment {
    FragmentTomatootherBinding binding;


    public tomatootherFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentTomatootherBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Tomato_Other_details);
        // Set the formatted text to the TextView
        binding.tomatootherdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}