public class RadishotherFragment extends Fragment {
    FragmentRadishotherBinding binding;

    public RadishotherFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentRadishotherBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Radish_Others);
        // Set the formatted text to the TextView
        binding.Radishotherdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}