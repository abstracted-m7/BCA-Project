public class RadishgrowingFragment extends Fragment {
    FragmentRadishgrowingBinding binding;

    public RadishgrowingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentRadishgrowingBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Radish_Growing_Process);
        // Set the formatted text to the TextView
        binding.Radishgrowingdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}