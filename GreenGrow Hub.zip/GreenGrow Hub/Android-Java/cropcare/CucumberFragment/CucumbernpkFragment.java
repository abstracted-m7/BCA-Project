public class CucumbernpkFragment extends Fragment {
    FragmentCucumbernpkBinding binding;

    public CucumbernpkFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCucumbernpkBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Cucumber_NPK_Fertilizer_and_Soil_Management);
        // Set the formatted text to the TextView
        binding.Cucumbernpkdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}