public class Sweet_PotatonpkFragment extends Fragment {
    FragmentSweetPotatonkpBinding binding;


    public Sweet_PotatonpkFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentSweetPotatonkpBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Sweet_Potato_NPK_Fertilizer_and_Soil_Management);
        // Set the formatted text to the TextView
        binding.SweetPotatonpkdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}