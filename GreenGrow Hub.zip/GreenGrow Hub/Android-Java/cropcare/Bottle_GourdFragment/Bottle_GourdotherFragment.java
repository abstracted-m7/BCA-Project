public class Bottle_GourdotherFragment extends Fragment {
    FragmentBottleGourdotherBinding binding;


    public Bottle_GourdotherFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentBottleGourdotherBinding.inflate(inflater, container, false);

        String rawText = getString(R.string.Bottle_Gourd_Others);
        // Set the formatted text to the TextView
        binding.BottleGourdotherdetail.setText(rawText);




        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}