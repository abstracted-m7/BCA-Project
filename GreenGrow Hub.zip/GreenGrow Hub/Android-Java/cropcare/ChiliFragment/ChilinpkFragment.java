public class ChilinpkFragment extends Fragment {
    FragmentChilinpkBinding binding;


    public ChilinpkFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentChilinpkBinding.inflate(inflater, container, false);
        String rawText = getString(R.string.Green_Chili_NPK_Fertilizer_and_Soil_Management);
        // Set the formatted text to the TextView
        binding.Chilinpkdetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}