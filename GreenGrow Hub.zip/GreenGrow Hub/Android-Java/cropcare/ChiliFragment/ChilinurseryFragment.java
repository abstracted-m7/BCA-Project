public class ChilinurseryFragment extends Fragment {
    FragmentChilinurseryBinding binding;


    public ChilinurseryFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentChilinurseryBinding.inflate(inflater, container, false);
        String rawText = getString(R.string.Green_Chili_Nursery);
        // Set the formatted text to the TextView
        binding.Chilinurserydetail.setText(rawText);


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}