public class ChiligrowingFragment extends Fragment {
    FragmentChiligrowingBinding binding;


    public ChiligrowingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentChiligrowingBinding.inflate(inflater, container, false);
        String rawText = getString(R.string.Green_Chili_Others);
        // Set the formatted text to the TextView
        binding.Chiligrowingdetail.setText(rawText);



        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}