public class ChiliotherFragment extends Fragment {
    FragmentChiliotherBinding binding;


    public ChiliotherFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentChiliotherBinding.inflate(inflater, container, false);
        String rawText = getString(R.string.Green_Chili_Others);
        // Set the formatted text to the TextView
        binding.Chiliotherdetail.setText(rawText);



        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}