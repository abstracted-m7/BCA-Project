public class fertilizerRecommendationActivity extends AppCompatActivity {
    private WebView webView;
    private static final String URL = "http://4fa0-2409-4060-2d86-988a-5dc6-4565-4c3f-8127.ngrok-free.app";//Replace with your host link

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_fertilizer_recommemd);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        webView = findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);  // Enable JavaScript if needed

        webView.setWebViewClient(new WebViewClient()); // Load inside WebView
        webView.loadUrl(URL); // Load ngrok webpage
    }
}