public class cropRecommendationActivity extends AppCompatActivity {

    private WebView webView;
    private static final String URL = "http://4886-2409-40e0-58-79a6-7d3e-d047-fe6f-6bb2.ngrok-free.app";//Replace with your host link

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_crop_recommend);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        webView = findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);  // Enable JavaScript if needed

        webView.setWebViewClient(new WebViewClient()); // Load inside WebView
        webView.loadUrl(URL); // Load ngrok webpage
    }
}